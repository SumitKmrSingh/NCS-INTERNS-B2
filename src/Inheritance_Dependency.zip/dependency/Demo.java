package dependency;

public class Demo {
    String name;
    Laptop laptop;
    Printer printer;

}
