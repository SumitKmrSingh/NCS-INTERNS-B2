package dependency;

public class Printer {
    public void printing(String str){
        System.out.println("Printing : "+str);
    }
}
