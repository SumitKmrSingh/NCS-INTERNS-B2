package dependency;

public class Processor {
    void startProcessor() {
        System.out.println("Processor starts processing.");
    }
}
