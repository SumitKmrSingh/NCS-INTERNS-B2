package Inheritance;

public class Hierachial {
}
