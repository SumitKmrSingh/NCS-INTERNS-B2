package Inheritance;

public class MultiLevelInheritance {
}
