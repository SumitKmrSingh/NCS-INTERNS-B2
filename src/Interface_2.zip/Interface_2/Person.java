package Interface_2;

public interface Person {
    void eat();
    void sleep();
}
