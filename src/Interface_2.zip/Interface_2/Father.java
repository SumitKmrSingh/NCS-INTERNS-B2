package Interface_2;

import Interfaces.Person;

interface Father extends Person {
    void work();
}
