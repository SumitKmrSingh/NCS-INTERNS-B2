package Interface_2;

interface Mother extends Person {
    void care();
}
