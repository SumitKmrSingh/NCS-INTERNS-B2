package Interface_2;

public class Client {
    public static void main(String[] args) {
        Child obj = new Child();
        obj.care();
        obj.eat();
        obj.sleep();
        obj.study();
        obj.work();
    }

}
