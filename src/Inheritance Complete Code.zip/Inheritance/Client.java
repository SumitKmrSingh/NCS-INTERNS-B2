package Inheritance;

public class Client {
}
