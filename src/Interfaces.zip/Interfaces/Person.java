package Interfaces;

public interface Person {
    abstract void eat();
    void sleep();
}
