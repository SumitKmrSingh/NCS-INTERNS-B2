package dependency;

public class Client {
    public static void main(String[] args) {
        Worker worker = new Worker();
        worker.printBook();
    }
}
